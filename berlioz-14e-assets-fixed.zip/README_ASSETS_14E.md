# Berlioz Conseil — Pack assets 14E corrigé

Source utilisée : `public/assets/Logo rond - Berlioz Conseil - Aurelien Picard.png`

Principes :

- logo rond complet conservé sur canevas 1024 x 1024, sans recadrage agressif ;
- fond blanc du logo source détouré vers transparence pour le logo rond ;
- couleurs internes conservées, aucun filtre colorimétrique appliqué ;
- WebP exporté en lossless ;
- favicon et PWA basés sur la bulle avec le chat, pas sur le logo rond complet ;
- bulle chat reconstruite depuis les pixels dorés source, sans arc extérieur ni texte résiduel ;
- icônes maskable générées avec marge de sécurité.

Gold bbox source : `(317, 127, 706, 518)`
Crop mark utilisé : `(272, 66, 751, 545)`
Limite verticale de la bulle : `526`
Couleur fond icônes échantillonnée depuis la source : `rgb(10, 28, 53)`
